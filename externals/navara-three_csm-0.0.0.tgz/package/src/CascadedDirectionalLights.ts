import {
  Color,
  DirectionalLight,
  Object3D,
  Vector3,
  type ColorRepresentation,
} from "three";

const DEFAULT_LIGHT_COLOR = new Color(0xffffff);

export class CascadedDirectionalLights extends Object3D {
  readonly mainLight: DirectionalLight;
  readonly cascadedLights: DirectionalLight[];

  // For convenience and stability of the values, because CascadedShadowMaps
  // modifies the positions of lights and their targets.
  // i.e. position.copy(direction).multiplyScalar(-1).add(target.position)
  direction = new Vector3(-1, -1, -1);

  constructor(color?: ColorRepresentation, intensity?: number) {
    super();
    const light = new DirectionalLight(color, intensity);
    light.castShadow = true;
    this.mainLight = light;
    this.cascadedLights = [light];
    this.add(light);
    this.add(light.target);
  }

  setCount(value: number): this {
    value = Math.max(1, value);
    const count = this.cascadedLights.length;
    if (value === count) {
      return this;
    }
    if (value > count) {
      const mainLight = this.mainLight;
      for (let i = count; i < value; ++i) {
        const light = mainLight.clone(); // Clones the shadow parameters as well.
        // Avoid accumulating that lighting color.
        light.color.copy(DEFAULT_LIGHT_COLOR);
        this.add(light);
        this.add(light.target);
        this.cascadedLights[i] = light;
      }
    } else {
      for (let i = value; i < count; ++i) {
        const light = this.cascadedLights[i];
        light.dispose();
        this.remove(light.target);
        this.remove(light);
      }
    }
    this.cascadedLights.length = value;
    return this;
  }

  dispose(): void {
    // eslint-disable-next-line @typescript-eslint/prefer-for-of
    for (let i = 0; i < this.cascadedLights.length; ++i) {
      this.cascadedLights[i].dispose();
    }
  }

  copy(source: this, _recursive?: boolean): this {
    super.copy(source, false);

    this.cascadedLights.length = 0;
    this.clear();

    for (const l of source.cascadedLights) {
      const cloned = l.clone();
      this.add(cloned);
      this.add(cloned.target);
      this.cascadedLights.push(cloned);
    }

    return this;
  }
}
